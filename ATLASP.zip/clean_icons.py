import os
import glob
import re

files = glob.glob('c:/Users/hp/Desktop/Audit interne/atlas-audit-platform/frontend/*.html')
for fpath in files:
    with open(fpath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Meta-pills clean up (remove FA from header)
    content = re.sub(r'<i class=\"fa[^>]+></i>', '', content)

    with open(fpath, 'w', encoding='utf-8') as f:
        f.write(content)
print('Cleaned up residual Font Awesome icons')
