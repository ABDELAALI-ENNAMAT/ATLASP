import glob
import re

files = glob.glob('c:/Users/hp/Desktop/Audit interne/atlas-audit-platform/frontend/*.html')

topbar_template = """        <header class="topbar">
          <div class="topbar-left">
            <div class="status-dot"></div>
            <span class="topbar-title">{title}</span>
          </div>
          <div class="topbar-right">
            <button class="btn btn-ghost btn-sm" onclick="window.location.href='/report'">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                <polyline points="7 10 12 15 17 10"></polyline>
                <line x1="12" y1="15" x2="12" y2="3"></line>
              </svg>
              Export PDF
            </button>
            <button class="theme-btn" id="theme-toggle" aria-label="Toggle theme">
              <svg id="theme-icon" viewBox="0 0 24 24" fill="none"
                   stroke="currentColor" stroke-width="2"
                   stroke-linecap="round" stroke-linejoin="round" width="16" height="16">
                <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
              </svg>
            </button>
          </div>
        </header>"""

for fpath in files:
    if 'upload.html' in fpath:
        continue
        
    with open(fpath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Get page title
    match = re.search(r'<div class="page-title">([^<]+)</div>', content)
    title = match.group(1) if match else "ATLAS Intelligence"
    
    # Clean up any existing topbar
    content = re.sub(r'<header class="topbar">.*?</header>', '', content, flags=re.DOTALL)
    
    # If the layout is not fixed (doesn't have main-area directly following aside)
    # The previous fix for report/settings/sampling might have injected main-area.
    # Let's cleanly reset the main-content and main-area wrappers
    
    # 1. remove existing <div class="main-area"> and </div> if they exist, to start fresh
    content = content.replace('<div class="main-area">', '')
    # 2. Revert <div class="main-content"> back to <main class="main-content"> just for standardizing our replacement
    content = content.replace('<div class="main-content">', '<main class="main-content">')
    
    # Now we have <aside>...</aside> ... <main class="main-content">
    # Let's build the correct structure
    
    topbar_html = topbar_template.format(title=title)
    
    # Replace <main class="main-content"> with the wrapper + topbar + main-content div
    replacement = f'''<div class="main-area">
{topbar_html}
        <div class="main-content">'''
        
    content = content.replace('<main class="main-content">', replacement)
    
    # Change </main> to </div></div>
    content = content.replace('</main>', '</div>\n        </div>')
    
    # Due to removing <div class="main-area"> earlier, we might have an extra closing </div> at the bottom for report/settings/sampling.
    # To fix this cleanly, let's just use regex to remove any extra </div> that are stacked before <script src="/js/api.js">
    # Wait, the safest way is:
    # 1. Read original content
    # 2. Extract <aside> block
    # 3. Extract main content block (everything inside <main> or <div class="main-content">)
    # 4. Extract script block at the bottom
    # 5. Rebuild the body entirely.
    
    with open(fpath, 'w', encoding='utf-8') as f:
        f.write(content)

print("Standardized layouts.")
