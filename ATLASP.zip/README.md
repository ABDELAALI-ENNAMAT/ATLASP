# ATLAS Audit Intelligence Platform

ATLAS is a professional-grade internal audit intelligence platform built for Meridian Cables Maroc SA. It operationalizes the COSO 2013 Internal Control framework and IIA standards by applying advanced data analytics (Benford's Law, Monte Carlo simulation, MUS sampling) to synthesize dynamic, risk-based audit insights.

## Setup Instructions
1. Install dependencies: `pip install -r requirements.txt`
2. Generate synthetic data: `python generate_data.py`
3. Start the server: `python run.py`

*Optional: Add `GEMINI_API_KEY=your_key` to a `.env` file to enable AI-enhanced report narratives.*

## Quick Demo Flow
1. Open your browser and navigate to `http://localhost:5000`
2. On the Upload page, click **Use Demo Data**
3. Wait for the engine to process the datasets and calculate the control gaps, exposure, and anomalies
4. Explore all 8 analytics pages through the sidebar

## Key Technical Features
- **Benford's Law Analysis:** Chi-square statistical testing on General Ledger data to detect fraudulent manipulation.
- **Monte Carlo Simulation:** NumPy-driven 10,000 iteration simulation to quantify P10/P50/P90 financial exposure.
- **Monetary Unit Sampling (MUS):** Statistical audit sampling prioritizing high-value transactions.
- **COSO 2013 & IIA Alignment:** Risks are dynamically mapped to COSO components and formatted strictly to IIA standard fields (Condition, Criteria, Cause, Effect, Recommendation).
- **Semantic PDF Analysis:** Regex and keyword clustering to detect policy deficiencies in unstructured text.

## Data Files Description
- `general_ledger.xlsx`: 2,500 transactions with engineered duplicate payments and threshold avoidance signals.
- `supplier_master.csv`: 180 vendors with concentration limit and audit backlog anomalies.
- `payroll.xlsx`: 300 employees including ghost employee payments post-termination.
- `kpi_data.xlsx`: 24 months of operational metrics showing degrading defect rates and IT downtime spikes.
- `procurement_policy.pdf`: Professional policy document intentionally omitting diversification controls.
- `it_security_policy.pdf`: Professional policy document intentionally omitting remote access and backup controls, with an outdated 2019 review date.
- `org_structure.csv`: Organizational hierarchy for scope mapping.
