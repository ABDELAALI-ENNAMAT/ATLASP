import os

def export_all_code():
    project_dir = os.path.dirname(os.path.abspath(__file__))
    output_file = os.path.join(project_dir, 'atlas_all_code.txt')
    
    # Extensions to include
    extensions = ['.py', '.html', '.css', '.js', '.json', '.md']
    
    # Directories to exclude
    exclude_dirs = ['.env', '__pycache__', 'outputs', 'data']
    
    with open(output_file, 'w', encoding='utf-8') as outfile:
        outfile.write("="*80 + "\n")
        outfile.write("ATLAS AUDIT INTELLIGENCE PLATFORM - COMPLETE CODEBASE\n")
        outfile.write("="*80 + "\n\n")
        
        for root, dirs, files in os.walk(project_dir):
            # Skip excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.')]
            
            for file in files:
                if any(file.endswith(ext) for ext in extensions):
                    file_path = os.path.join(root, file)
                    rel_path = os.path.relpath(file_path, project_dir)
                    
                    # Don't include the export script itself or the output file
                    if file == 'export_code.py' or file == 'atlas_all_code.txt':
                        continue
                        
                    try:
                        with open(file_path, 'r', encoding='utf-8') as infile:
                            content = infile.read()
                            
                        outfile.write("\n" + "="*80 + "\n")
                        outfile.write(f"FILE: {rel_path}\n")
                        outfile.write("="*80 + "\n\n")
                        outfile.write(content)
                        outfile.write("\n")
                    except Exception as e:
                        outfile.write(f"\n[Could not read file {rel_path}: {e}]\n")
                        
    print(f"All code successfully exported to {output_file}")

if __name__ == "__main__":
    export_all_code()
