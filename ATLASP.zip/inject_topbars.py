import glob
import os
import re

files = glob.glob('c:/Users/hp/Desktop/Audit interne/atlas-audit-platform/frontend/*.html')

for fpath in files:
    if 'upload.html' in fpath:
        continue

    with open(fpath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Extract the page title for the topbar
    # Try to find <div class="page-title">TITLE</div>
    match = re.search(r'<div class="page-title">([^<]+)</div>', content)
    page_title = match.group(1) if match else "ATLAS Intelligence"

    # Only inject if not already present
    if '<header class="topbar">' not in content:
        topbar_html = f'''
        <header class="topbar">
          <div class="topbar-left">
            <div class="status-dot"></div>
            <span class="topbar-title">{page_title}</span>
          </div>
          <div class="topbar-right">
            <button class="btn btn-ghost btn-sm" onclick="window.location.href='/report'">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                <polyline points="7 10 12 15 17 10"></polyline>
                <line x1="12" y1="15" x2="12" y2="3"></line>
              </svg>
              Export PDF
            </button>
            <button class="theme-btn" id="theme-toggle" aria-label="Toggle theme">
              <svg id="theme-icon" viewBox="0 0 24 24" fill="none"
                   stroke="currentColor" stroke-width="2"
                   stroke-linecap="round" stroke-linejoin="round" width="16" height="16">
                <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
              </svg>
            </button>
          </div>
        </header>
'''

        # We need to insert this right after <div class="main-area"> or before <main class="main-content">
        if '<div class="main-area">' in content:
            content = content.replace('<div class="main-area">', f'<div class="main-area">\n{topbar_html}')
        elif '<main class="main-content">' in content:
            # First, we also need to wrap with <div class="main-area"> for these pages too, wait...
            # The prompt only said to fix layout for report, settings, sampling.
            # But topbar makes sense before main-content or inside main-area.
            # Let's see if we should just insert before main-content.
            content = content.replace('<main class="main-content">', f'{topbar_html}\n        <main class="main-content">')
            
        with open(fpath, 'w', encoding='utf-8') as f:
            f.write(content)

print("Injected topbars.")
