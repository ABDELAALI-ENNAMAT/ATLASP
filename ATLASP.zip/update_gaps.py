import os
import re

fpath = 'c:/Users/hp/Desktop/Audit interne/atlas-audit-platform/frontend/gaps.html'
with open(fpath, 'r', encoding='utf-8') as f:
    content = f.read()

# Replace the table structure with a simple container
table_structure = """                <div class="card" style="padding: 0;">
                    <div class="card-header" style="padding: 20px 24px 0;"><h3>Detailed Findings</h3></div>
                    <div class="table-wrapper" style="border: none; margin-top: 16px; border-radius: 0 0 var(--radius-lg) var(--radius-lg);">
                        <table style="table-layout: fixed; width: 100%;">
                            <thead>
                                <tr>
                                    <th style="width: 30%;">Control Objective</th>
                                    <th style="width: 20%;">Category</th>
                                    <th style="width: 15%;">Status</th>
                                    <th style="width: 20%;">Standard</th>
                                    <th style="width: 15%;">Action Required</th>
                                </tr>
                            </thead>
                            <tbody id="gapsTable"></tbody>
                        </table>
                    </div>
                </div>"""

new_container = """                <div class="page-header" style="margin-top:var(--sp-8);">
                    <h2 class="page-title" style="font-size:var(--text-xl);">Detailed Findings</h2>
                </div>
                <div id="gapsList"></div>"""
content = content.replace(table_structure, new_container)

# Now replace the script part that renders the rows
script_find = """            const tbody = document.getElementById('gapsTable');
            data.matrix.forEach((m, idx) => {
                const tr = document.createElement('tr');
                tr.style.cursor = 'pointer';
                tr.onclick = () => toggleFinding(`finding-${idx}`);
                
                let badgeCls = 'badge-moderate';
                if(m.status === 'Strong') badgeCls = 'badge-low';
                if(m.status === 'None') badgeCls = 'badge-critical';
                
                tr.innerHTML = `
                    <td style="font-weight:500;">${m.control}</td>
                    <td><span class="badge badge-low">${m.category}</span></td>
                    <td><span class="badge ${badgeCls}">${m.status}</span></td>
                    <td style="font-size:0.75rem;color:var(--text-secondary);">COSO Principle 10</td>
                    <td><button class="btn btn-sm btn-secondary" onclick="event.stopPropagation();"> Assign</button></td>
                `;
                tbody.appendChild(tr);
                
                const detailTr = document.createElement('tr');
                detailTr.id = `finding-${idx}`;
                detailTr.className = 'finding-row';
                detailTr.innerHTML = `
                    <td colspan="5" style="padding:16px 24px;">
                        <div style="display:flex;gap:24px;">
                            <div style="flex:1;">
                                <div style="font-size:0.7rem;font-weight:600;text-transform:uppercase;color:var(--text-muted);margin-bottom:4px;">Policy Source</div>
                                <div style="font-size:0.875rem;font-weight:500;">${m.policy_source}</div>
                            </div>
                            <div style="flex:2;">
                                <div style="font-size:0.7rem;font-weight:600;text-transform:uppercase;color:var(--text-muted);margin-bottom:4px;">Audit Finding</div>
                                <div style="font-size:0.875rem;color:var(--text-secondary);">
                                    ${m.status === 'None' ? `The required control "${m.control}" was not found in the source policy document. This represents a design gap in the control environment.` : `The control "${m.control}" is present in the policy document and assessed as ${m.status}.`}
                                </div>
                            </div>
                        </div>
                    </td>
                `;
                tbody.appendChild(detailTr);
            });"""

new_script = """            const gapsList = document.getElementById('gapsList');
            data.matrix.forEach((m, idx) => {
                let findingSev = 'finding-medium';
                let sevLevel = 'Moderate';
                let sevClass = 'sev-medium';
                let ctrlClass = 'ctrl-partial';
                
                if (m.status === 'None' || m.status === 'No Control') {
                    findingSev = 'finding-critical';
                    sevLevel = 'Critical';
                    sevClass = 'sev-critical';
                    ctrlClass = 'ctrl-none';
                } else if (m.status === 'Weak') {
                    findingSev = 'finding-high';
                    sevLevel = 'High';
                    sevClass = 'sev-high';
                    ctrlClass = 'ctrl-weak';
                } else if (m.status === 'Strong' || m.status === 'Adequate') {
                    findingSev = 'finding-low';
                    sevLevel = 'Low';
                    sevClass = 'sev-low';
                    ctrlClass = 'ctrl-strong';
                }
                
                const condition = m.status === 'None' 
                    ? `The required control "${m.control}" was not found in the source policy document (${m.policy_source}).`
                    : `The control "${m.control}" is present but assessed as ${m.status}.`;
                    
                const card = document.createElement('div');
                card.className = `finding-card ${findingSev}`;
                card.innerHTML = `
                    <div class="finding-header">
                        <div>
                            <div class="finding-title">${m.control}</div>
                            <div style="font-size:10px;color:var(--color-text-faint);margin-top:2px;">
                                COSO Principle 10 · ${m.category}
                            </div>
                        </div>
                        <div style="display:flex;gap:var(--sp-2);align-items:center;">
                            <span class="severity-badge ${sevClass}">${sevLevel}</span>
                            <span class="control-pill ${ctrlClass}">${m.status}</span>
                        </div>
                    </div>
                    <div class="finding-field">
                        <div class="finding-field-label">Condition</div>
                        <div class="finding-field-value">${condition}</div>
                    </div>
                    <div class="finding-field">
                        <div class="finding-field-label">Criteria</div>
                        <div class="finding-field-value">IIA Standards / Best Practice Policy Design</div>
                    </div>
                    <div class="finding-field">
                        <div class="finding-field-label">Cause</div>
                        <div class="finding-field-value">Lack of formalization or outdated policy document.</div>
                    </div>
                    <div class="finding-field">
                        <div class="finding-field-label">Effect</div>
                        <div class="finding-field-value">Increased risk of process breakdown or unauthorized actions due to undocumented controls.</div>
                    </div>
                    <div class="finding-rec">
                        <strong>Recommendation</strong>
                        Update the ${m.policy_source} to explicitly define and enforce the "${m.control}" requirement.
                    </div>
                `;
                gapsList.appendChild(card);
            });"""

content = content.replace(script_find, new_script)

with open(fpath, 'w', encoding='utf-8') as f:
    f.write(content)
print("Updated gaps.html")
