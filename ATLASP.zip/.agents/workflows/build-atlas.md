---
name: build-atlas
description: Builds the full ATLAS platform phase by phase with verification at each step
---

## Build workflow

Execute in this exact order. Stop and show me what you built after each phase before proceeding.

Phase 1: Generate all synthetic data files → save to /data/demo/
Phase 2: Build Flask backend skeleton + all API endpoints (empty stubs)
Phase 3: Build all Python analysis modules (benford, monte_carlo, risk_engine, control_gaps, report_gen)
Phase 4: Build the frontend HTML/CSS/JS for all 8 pages
Phase 5: Wire frontend to backend (connect all fetch() calls to real Flask endpoints)
Phase 6: Generate the Word document template and Jinja2 report template
Phase 7: Create requirements.txt, run.py, and README.md
Phase 8: Run the app and verify in browser that all 8 pages load correctly

After Phase 8, take a screenshot of the dashboard and show it to me.
