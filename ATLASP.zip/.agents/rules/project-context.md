# ATLAS Project Context Rule

## What this project is
ATLAS is a professional internal audit risk intelligence web application built for a portfolio presentation. It analyzes uploaded company data files and produces a complete audit risk package following IIA standards and the COSO 2013 framework.

## Tech stack (NEVER deviate from this)
- Backend: Python 3.11 + Flask (NOT FastAPI, NOT Django, NOT Streamlit)
- Data processing: pandas, numpy, openpyxl, pdfplumber
- Analysis: scipy (Benford's Law chi-square test), scikit-learn (only for sampling module)
- Reporting: python-docx, reportlab, Jinja2
- Frontend: Pure HTML5 + CSS3 + Vanilla JavaScript (NO React, NO Vue, NO Bootstrap, NO Tailwind, NO jQuery)
- Charts: Chart.js 4.x loaded from CDN
- Icons: Font Awesome 6 Free loaded from CDN

## Architecture
- Flask backend serves API endpoints at /api/*
- Flask also serves all HTML pages as static files from /frontend/
- All analysis runs in Python backend modules
- Frontend calls backend via fetch() API
- No database — all state held in Flask session or returned as JSON

## Code style rules
- Python: PEP 8, clear docstrings on every function, type hints
- JavaScript: ES6+, no var (only const and let), async/await for all fetch calls
- CSS: CSS custom properties (variables) for all colors and spacing, mobile-responsive
- All monetary amounts displayed in MAD (Moroccan Dirham) with thousand separators
- All risk scores follow IIA terminology: Likelihood (1-5), Impact (1-5), Risk Score = L × I

## IIA and COSO terminology (always use these exact terms)
- Risk levels: Low (score 1-3), Moderate (4-6), High (7-12), Critical (15-25)  
- COSO components: Control Environment, Risk Assessment, Control Activities, Information & Communication, Monitoring Activities
- Audit finding structure: Condition, Criteria, Cause, Effect, Recommendation
- Control status values: "No Control", "Weak Control", "Adequate Control", "Strong Control"

## What NOT to do
- Never use Streamlit
- Never use a SQL database
- Never install heavy ML models (no PyTorch, no Transformers, no LLaMA)
- Never use random data that changes on every reload — all synthetic data is pre-generated and saved to files
- Never use placeholder "TODO" comments in final code
- Never hardcode file paths — always use os.path or pathlib
