import os
import glob
import re

files = glob.glob('c:/Users/hp/Desktop/Audit interne/atlas-audit-platform/frontend/*.html')

sidebar_template = '''        <nav class="sidebar">
            <div class="sidebar-logo-area">
                <div class="logo-mark">
                    <div class="logo-icon">
                        <i class="fa-solid fa-shield-check" style="font-size:0.875rem; color:white;"></i>
                    </div>
                    <div class="logo-text">ATLAS</div>
                </div>
                <div class="sidebar-company">
                    <div class="sidebar-company-name">Meridian Cables Maroc SA</div>
                    <div class="sidebar-company-meta">Manufacturing · FY 2024</div>
                    <div class="sidebar-status">
                        <div class="status-dot"></div>
                        <div class="status-text">Analysis complete</div>
                    </div>
                </div>
            </div>

            <div class="sidebar-nav">
                <div class="nav-section">
                    <div class="nav-section-label">Analytics</div>
                    <a href="/dashboard" class="nav-link{dash_act}">
                        <i class="fa-solid fa-gauge-high nav-icon"></i> Overview
                    </a>
                    <a href="/heatmap" class="nav-link{heat_act}">
                        <i class="fa-solid fa-grip nav-icon"></i> Risk heat map
                    </a>
                    <a href="/register" class="nav-link{reg_act}">
                        <i class="fa-solid fa-table-list nav-icon"></i> Risk register
                    </a>
                </div>
                <div class="nav-section">
                    <div class="nav-section-label">Finance</div>
                    <a href="/exposure" class="nav-link{exp_act}">
                        <i class="fa-solid fa-chart-bar nav-icon"></i> Financial exposure
                    </a>
                    <a href="/anomalies" class="nav-link{anom_act}">
                        <i class="fa-solid fa-wave-square nav-icon"></i> Anomaly detection
                    </a>
                </div>
                <div class="nav-section">
                    <div class="nav-section-label">Audit</div>
                    <a href="/gaps" class="nav-link{gaps_act}">
                        <i class="fa-solid fa-shield-halved nav-icon"></i> Control gaps
                    </a>
                    <a href="/sampling" class="nav-link{samp_act}">
                        <i class="fa-solid fa-calculator nav-icon"></i> Audit sampling
                    </a>
                    <a href="/report" class="nav-link{rep_act}">
                        <i class="fa-solid fa-file-lines nav-icon"></i> Audit report
                    </a>
                    <a href="/upload" class="nav-link{up_act}">
                        <i class="fa-solid fa-upload nav-icon"></i> Upload data
                    </a>
                </div>
                <div class="nav-section">
                    <div class="nav-section-label">Settings</div>
                    <a href="/settings" class="nav-link{set_act}">
                        <i class="fa-solid fa-gear nav-icon"></i> Configuration
                    </a>
                </div>
            </div>

            <div class="sidebar-footer">
                <div class="sidebar-version">ATLAS v1.0 · IIA Standards · COSO 2013</div>
            </div>
        </nav>'''

emoji_replacements = {
    '⚠': '<i class="fa-solid fa-triangle-exclamation"></i>',
    '🔴': '<i class="fa-solid fa-circle" style="color:var(--risk-critical-fill);"></i>',
    '🟡': '<i class="fa-solid fa-circle" style="color:var(--risk-moderate-fill);"></i>',
    '🟠': '<i class="fa-solid fa-circle" style="color:var(--risk-high-fill);"></i>',
    '📋': '<i class="fa-solid fa-clipboard-list"></i>',
    '📏': '<i class="fa-solid fa-ruler"></i>',
    '🔍': '<i class="fa-solid fa-magnifying-glass"></i>',
    '⚡': '<i class="fa-solid fa-bolt"></i>',
    '✅': '<i class="fa-solid fa-circle-check"></i>',
    '↑': '<i class="fa-solid fa-cloud-arrow-up"></i>'
}

for fpath in files:
    fname = os.path.basename(fpath)
    if fname in ['upload.html', 'dashboard.html']:
        continue
    with open(fpath, 'r', encoding='utf-8') as f:
        content = f.read()

    # 1. Add FA CDN
    if 'font-awesome' not in content:
        content = content.replace('</head>', '    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">\n</head>')

    # 2. Replace sidebar
    sidebar_match = re.search(r'<nav class="sidebar">.*?</nav>', content, flags=re.DOTALL)
    if sidebar_match:
        dash_act = ' active' if fname == 'dashboard.html' else ''
        heat_act = ' active' if fname == 'heatmap.html' else ''
        reg_act = ' active' if fname == 'register.html' else ''
        exp_act = ' active' if fname == 'exposure.html' else ''
        anom_act = ' active' if fname == 'anomalies.html' else ''
        gaps_act = ' active' if fname == 'gaps.html' else ''
        samp_act = ' active' if fname == 'sampling.html' else ''
        rep_act = ' active' if fname == 'report.html' else ''
        up_act = ' active' if fname == 'upload.html' else ''
        set_act = ' active' if fname == 'settings.html' else ''
        
        new_sidebar = sidebar_template.format(
            dash_act=dash_act, heat_act=heat_act, reg_act=reg_act, 
            exp_act=exp_act, anom_act=anom_act, gaps_act=gaps_act, 
            samp_act=samp_act, rep_act=rep_act, up_act=up_act, set_act=set_act
        )
        content = content.replace(sidebar_match.group(0), new_sidebar)

    # 3. Replace emojis
    for em, fa in emoji_replacements.items():
        # Avoid replacing '↑' inside tags if any exist
        if em == '↑':
            # Safe replace for standalone ↑
            content = content.replace('>↑<', f'>{fa}<')
        else:
            content = content.replace(em, fa)

    # Fix anomalies KPI icons specifically
    if fname == 'anomalies.html':
        content = content.replace(
            '<div style="width:32px;height:32px;border-radius:4px;background:var(--risk-critical-bg);color:var(--risk-critical-fill);display:flex;align-items:center;justify-content:center;font-size:1.2rem;"><i class="fa-solid fa-circle" style="color:var(--risk-critical-fill);"></i></div>',
            '<div style="width:34px;height:34px;border-radius:var(--radius-sm);background:var(--risk-critical-bg);display:flex;align-items:center;justify-content:center;"><i class="fa-solid fa-copy" style="color:var(--risk-critical-fill);font-size:0.85rem;"></i></div>'
        )
        content = content.replace(
            '<div style="width:32px;height:32px;border-radius:4px;background:var(--risk-moderate-bg);color:var(--risk-moderate-fill);display:flex;align-items:center;justify-content:center;font-size:1.2rem;"><i class="fa-solid fa-circle" style="color:var(--risk-moderate-fill);"></i></div>',
            '<div style="width:34px;height:34px;border-radius:var(--radius-sm);background:var(--risk-moderate-bg);display:flex;align-items:center;justify-content:center;"><i class="fa-solid fa-triangle-exclamation" style="color:var(--risk-moderate-fill);font-size:0.85rem;"></i></div>'
        )
        content = content.replace(
            '<div style="width:32px;height:32px;border-radius:4px;background:var(--risk-high-bg);color:var(--risk-high-fill);display:flex;align-items:center;justify-content:center;font-size:1.2rem;"><i class="fa-solid fa-circle" style="color:var(--risk-high-fill);"></i></div>',
            '<div style="width:34px;height:34px;border-radius:var(--radius-sm);background:var(--risk-high-bg);display:flex;align-items:center;justify-content:center;"><i class="fa-solid fa-chart-line" style="color:var(--risk-high-fill);font-size:0.85rem;"></i></div>'
        )
    
    with open(fpath, 'w', encoding='utf-8') as f:
        f.write(content)

print('Updated HTML files.')
