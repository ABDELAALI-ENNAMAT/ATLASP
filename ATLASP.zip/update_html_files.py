import os
import glob
import re

files = glob.glob('c:/Users/hp/Desktop/Audit interne/atlas-audit-platform/frontend/*.html')

sidebar_template = '''<aside class="sidebar">
  <!-- Logo -->
  <div class="sidebar-logo">
    <svg class="logo-mark" viewBox="0 0 32 32" fill="none" aria-label="ATLAS logo">
      <rect width="32" height="32" rx="8" fill="var(--color-primary)" opacity="0.15"/>
      <path d="M7 25 L16 7 L25 25" stroke="var(--color-primary)" stroke-width="2.5"
            stroke-linecap="round" stroke-linejoin="round" fill="none"/>
      <circle cx="16" cy="21" r="2.5" fill="var(--color-primary)"/>
      <path d="M11 25 L21 25" stroke="var(--color-primary)" stroke-width="2"
            stroke-linecap="round" opacity="0.4"/>
    </svg>
    <div>
      <div class="logo-text">ATLAS</div>
      <div class="logo-sub">Risk Intelligence</div>
    </div>
  </div>

  <div class="sidebar-section">
    <!-- Analytics group -->
    <div class="sidebar-label">Analytics</div>
    <a href="/dashboard" class="nav-item {dash_act}">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
      Overview
    </a>
    <a href="/heatmap" class="nav-item {heat_act}">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="4" height="4"/><rect x="10" y="3" width="4" height="4"/><rect x="17" y="3" width="4" height="4"/><rect x="3" y="10" width="4" height="4"/><rect x="10" y="10" width="4" height="4"/><rect x="17" y="10" width="4" height="4"/><rect x="3" y="17" width="4" height="4"/><rect x="10" y="17" width="4" height="4"/><rect x="17" y="17" width="4" height="4"/></svg>
      Risk Heat Map
    </a>
    <a href="/register" class="nav-item {reg_act}">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14,2 14,8 20,8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
      Risk Register
    </a>

    <!-- Finance group -->
    <div class="sidebar-label" style="margin-top:var(--sp-4);">Finance</div>
    <a href="/exposure" class="nav-item {exp_act}">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
      Financial Exposure
    </a>
    <a href="/anomalies" class="nav-item {anom_act}">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22,12 18,12 15,21 9,3 6,12 2,12"/></svg>
      Anomaly Detection
    </a>

    <!-- Audit group -->
    <div class="sidebar-label" style="margin-top:var(--sp-4);">Audit</div>
    <a href="/gaps" class="nav-item {gaps_act}">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
      Control Gaps
    </a>
    <a href="/sampling" class="nav-item {samp_act}">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="2" width="16" height="20" rx="2"/><line x1="8" y1="7" x2="16" y2="7"/><line x1="8" y1="11" x2="16" y2="11"/><line x1="8" y1="15" x2="12" y2="15"/></svg>
      Audit Sampling
    </a>
    <a href="/report" class="nav-item {rep_act}">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22,12 18,12 15,21 9,3 6,12 2,12"/></svg>
      Audit Report
    </a>
    <a href="/upload" class="nav-item {up_act}">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17,8 12,3 7,8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
      Upload Data
    </a>

    <!-- Settings -->
    <div class="sidebar-label" style="margin-top:var(--sp-4);">System</div>
    <a href="/settings" class="nav-item {set_act}">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
      Configuration
    </a>
  </div>

  <!-- User footer -->
  <div class="sidebar-bottom">
    <div class="sidebar-user">
      <div class="user-avatar">IA</div>
      <div>
        <div class="user-name">Internal Auditor</div>
        <div class="user-role">Meridian Cables Maroc SA · FY 2024</div>
      </div>
    </div>
  </div>
</aside>'''

topbar_template = '''<header class="topbar">
  <div class="topbar-left">
    <div class="status-dot"></div>
    <span class="topbar-title" id="topbar-page-title">{title}</span>
    <span style="font-size:var(--text-xs);color:var(--color-text-faint);">·</span>
    <span style="font-size:var(--text-xs);color:var(--color-text-muted);">
      Meridian Cables Maroc SA · Manufacturing · FY 2024
    </span>
  </div>
  <div class="topbar-right">
    <button class="btn btn-ghost btn-sm" onclick="window.location.href='/report'">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7,10 12,15 17,10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
      Export PDF
    </button>
    <button class="theme-btn" id="theme-toggle" aria-label="Toggle theme">
      <svg id="theme-icon" width="16" height="16" viewBox="0 0 24 24" fill="none"
           stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
      </svg>
    </button>
  </div>
</header>'''

theme_js = '''
<!-- ── THEME TOGGLE ────────────────────────────────── -->
<script>
(function() {
  const html = document.documentElement;
  const btn  = document.getElementById('theme-toggle');
  const icon = document.getElementById('theme-icon');

  const MOON_PATH = `<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>`;
  const SUN_PATH  = `<circle cx="12" cy="12" r="5"/>
    <line x1="12" y1="1" x2="12" y2="3"/>
    <line x1="12" y1="21" x2="12" y2="23"/>
    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/>
    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
    <line x1="1" y1="12" x2="3" y2="12"/>
    <line x1="21" y1="12" x2="23" y2="12"/>
    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/>
    <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>`;

  // Load saved preference
  const saved = localStorage.getItem('atlas-theme') || 'dark';
  html.setAttribute('data-theme', saved);
  if (icon) icon.innerHTML = saved === 'dark' ? MOON_PATH : SUN_PATH;

  if (btn) {
    btn.addEventListener('click', () => {
      const current = html.getAttribute('data-theme');
      const next    = current === 'dark' ? 'light' : 'dark';
      html.setAttribute('data-theme', next);
      localStorage.setItem('atlas-theme', next);
      if (icon) icon.innerHTML = next === 'dark' ? MOON_PATH : SUN_PATH;
    });
  }
})();
</script>
</body>'''

page_titles = {
    'dashboard.html': 'Executive Dashboard',
    'heatmap.html': 'Risk Heat Map',
    'register.html': 'Risk Register',
    'exposure.html': 'Financial Exposure',
    'anomalies.html': 'Anomaly Detection',
    'gaps.html': 'Control Gaps',
    'sampling.html': 'Audit Sampling',
    'report.html': 'Audit Report',
    'upload.html': 'Upload Data',
    'settings.html': 'Configuration'
}

for fpath in files:
    fname = os.path.basename(fpath)
    with open(fpath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Remove old links
    content = re.sub(r'<link[^>]*font-awesome[^>]*>', '', content)
    content = re.sub(r'<link[^>]*components\.css[^>]*>', '', content)

    # Inject icons script if not exists
    if 'icons.js' not in content:
        content = content.replace('</head>', '    <script src="/js/icons.js"></script>\n</head>')

    # Replace Sidebar
    sidebar_match = re.search(r'<nav class="sidebar">.*?</nav>', content, flags=re.DOTALL)
    if not sidebar_match:
        sidebar_match = re.search(r'<aside class="sidebar">.*?</aside>', content, flags=re.DOTALL)
    if sidebar_match:
        new_sidebar = sidebar_template.format(
            dash_act='active' if fname == 'dashboard.html' else '',
            heat_act='active' if fname == 'heatmap.html' else '',
            reg_act='active' if fname == 'register.html' else '',
            exp_act='active' if fname == 'exposure.html' else '',
            anom_act='active' if fname == 'anomalies.html' else '',
            gaps_act='active' if fname == 'gaps.html' else '',
            samp_act='active' if fname == 'sampling.html' else '',
            rep_act='active' if fname == 'report.html' else '',
            up_act='active' if fname == 'upload.html' else '',
            set_act='active' if fname == 'settings.html' else ''
        )
        content = content.replace(sidebar_match.group(0), new_sidebar)

    # Replace Topbar
    topbar_match = re.search(r'<header class="topbar">.*?</header>', content, flags=re.DOTALL)
    if topbar_match:
        title = page_titles.get(fname, 'ATLAS')
        new_topbar = topbar_template.format(title=title)
        content = content.replace(topbar_match.group(0), new_topbar)

    # Inject theme toggle
    # Remove existing theme script if exists
    content = re.sub(r'<!-- ── THEME TOGGLE.*?</body>', '</body>', content, flags=re.DOTALL)
    content = content.replace('</body>', theme_js)

    with open(fpath, 'w', encoding='utf-8') as f:
        f.write(content)

print("Phase 1 replacements done.")
