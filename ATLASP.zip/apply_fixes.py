import glob
import re

files = glob.glob('c:/Users/hp/Desktop/Audit interne/atlas-audit-platform/frontend/*.html')

for fpath in files:
    with open(fpath, 'r', encoding='utf-8') as f:
        content = f.read()

    # FIX 1: Add data-theme="dark" to html tag if not present
    content = re.sub(r'<html([^>]*)>', lambda m: '<html' + m.group(1) + ('' if 'data-theme' in m.group(1) else ' data-theme="dark"') + '>', content)

    # FIX 5: session_id from URL and localStorage
    old_session_js = "const sid = new URLSearchParams(window.location.search).get('session_id') || '';"
    new_session_js = "const sid = new URLSearchParams(window.location.search).get('session_id') || localStorage.getItem('atlas-session-id') || '';"
    content = content.replace(old_session_js, new_session_js)

    # FIX 7: Page layouts for report.html, settings.html, sampling.html
    # Insert main-area wrapper
    if fpath.endswith('report.html') or fpath.endswith('settings.html') or fpath.endswith('sampling.html'):
        if 'class="main-area"' not in content:
            # We need to wrap <header class="topbar"> and <main class="main-content"> inside <div class="main-area">
            # First change <main class="main-content"> to <div class="main-content">
            content = content.replace('<main class="main-content">', '<div class="main-content">')
            content = content.replace('</main>', '</div>')
            
            # Now wrap everything after </aside> up to the last </div> before app-layout closes.
            # Easiest way is to replace </aside> with </aside>\n<div class="main-area">
            content = content.replace('</aside>', '</aside>\n        <div class="main-area">')
            
            # And add a closing </div> before the final app-layout closing </div>
            content = content.replace('</div>\n    \n    <script src="/js/api.js"></script>', '</div>\n    </div>\n    <script src="/js/api.js"></script>')

    # FIX 8: register.html inline CSS replace
    if 'register.html' in fpath:
        content = content.replace('var(--border-default)', 'var(--color-border)')
        content = content.replace('var(--bg-surface)', 'var(--color-surface)')
        content = content.replace('var(--brand-primary)', 'var(--color-primary)')
        content = content.replace('var(--radius-pill)', 'var(--r-full)')
        content = content.replace('var(--radius-sm)', 'var(--r-sm)')
        content = content.replace('var(--text-secondary)', 'var(--color-text-muted)')
        content = content.replace('var(--text-primary)', 'var(--color-text)')

    # FIX 9: settings.html input styles
    if 'settings.html' in fpath:
        old_card_body = '''<div class="card-body">
                            <p style="color:var(--text-secondary); margin-bottom:16px; font-size:0.875rem;">
                                Optional. When configured, enables AI-enhanced narrative generation in the audit report using Gemini API.
                                The app works fully without this key.
                            </p>
                            <div style="margin-bottom:16px;">
                                <label style="display:block; margin-bottom:8px; font-weight:600; font-size:0.75rem;">Google Gemini API Key</label>
                                <input type="password" id="apiKey" placeholder="AIzaSy..." style="width:100%; max-width:400px; padding:8px 12px; border:1px solid var(--border-default); border-radius:var(--radius-md); background:var(--bg-canvas); color:var(--text-primary);">
                            </div>
                            <div style="display:flex; align-items:center; gap:16px;">
                                <button class="btn btn-primary" onclick="saveKey()">Save API Key</button>
                                <span id="keyStatus" style="font-size:0.75rem; color:var(--text-secondary);">Not configured</span>
                            </div>
                        </div>'''
        new_card_body = '''<div class="card-body">
                            <p style="font-size:var(--text-sm);color:var(--color-text-muted);
                                      margin-bottom:var(--sp-5);line-height:1.6;">
                                Optional. When configured, enables AI-enhanced narrative generation 
                                in the audit report using Gemini API. The app works fully without this key.
                            </p>
                            <div style="margin-bottom:var(--sp-4);">
                                <label>Google Gemini API Key</label>
                                <input type="password" id="apiKey" placeholder="AIzaSy..."
                                       class="form-input" style="max-width:420px;">
                            </div>
                            <div style="display:flex;align-items:center;gap:var(--sp-4);">
                                <button class="btn btn-primary" onclick="saveKey()">
                                    Save API Key
                                </button>
                                <span id="keyStatus" style="font-size:var(--text-xs);
                                      color:var(--color-text-muted);">Not configured</span>
                            </div>
                        </div>'''
        content = content.replace(old_card_body, new_card_body)

    with open(fpath, 'w', encoding='utf-8') as f:
        f.write(content)

print('Applied HTML fixes.')
