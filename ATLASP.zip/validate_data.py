import pandas as pd, os

data_dir = 'c:/Users/hp/Desktop/Audit interne/atlas-audit-platform/data/demo'
files = os.listdir(data_dir)
print("Files generated:", files)

# Check 1: GL row count
gl = pd.read_excel(f'{data_dir}/general_ledger.xlsx')
print(f"GL rows: {len(gl)} (expected 2500)")

# Check 2: Duplicate signal exists
mecatelec = gl[gl['Vendor_Customer'] == 'MECATELEC SARL']
print(f"MECATELEC rows: {len(mecatelec)} (expected 28)")

# Check 3: NEXANS concentration
proc = gl[gl['Department'] == 'Procurement']
nexans_spend = gl[gl['Vendor_Customer'] == 'NEXANS MAROC']['Amount_MAD'].sum()
proc_spend = proc['Amount_MAD'].sum()
print(f"NEXANS % of Procurement spend: {nexans_spend/proc_spend*100:.1f}% (expected 34-40%)")

# Check 4: Threshold avoidance
thresh_10k = gl[(gl['Amount_MAD'] >= 9100) & (gl['Amount_MAD'] <= 9870)]
print(f"Threshold avoidance rows (9.1k-9.87k): {len(thresh_10k)} (expected ~23)")

# Check 5: Ghost employees in payroll
payroll_trans = pd.read_excel(f'{data_dir}/payroll.xlsx', sheet_name='Monthly_Transactions')
ghost_nov = payroll_trans[(payroll_trans['Employee_ID'].isin(['E0291','E0305'])) & 
                          (payroll_trans['Month'].isin(['2024-11','2024-12']))]
print(f"Ghost employee payments (Nov-Dec): {len(ghost_nov)} (expected 4)")

# Check 6: Supplier concentration
suppliers = pd.read_csv(f'{data_dir}/supplier_master.csv')
total = suppliers['Annual_Spend_MAD'].sum()
nexans_pct = suppliers[suppliers['Supplier_Name']=='NEXANS MAROC']['Annual_Spend_MAD'].values[0] / total * 100
print(f"NEXANS supplier concentration: {nexans_pct:.1f}% (expected ~38%)")

# Check 7: IT downtime spike
kpi = pd.read_excel(f'{data_dir}/kpi_data.xlsx')
sep_2024 = kpi[kpi['Month'] == '2024-09']
print(f"IT downtime Sep 2024: {sep_2024['IT_Downtime_Hours'].values[0]} hours (expected 63)")

# Check 8: Single source suppliers before 2021
suppliers['Last_Audit_Date'] = pd.to_datetime(suppliers['Last_Audit_Date'])
old_single = suppliers[(suppliers['Single_Source'] == 'Y') & 
                       (suppliers['Last_Audit_Date'] < '2021-01-01')]
print(f"Single-source suppliers with old audits: {len(old_single)} (expected 9)")

print("Validation complete.")
