import glob

files = glob.glob('c:/Users/hp/Desktop/Audit interne/atlas-audit-platform/frontend/*.html')

INSERT = "      window.dispatchEvent(new CustomEvent('atlas-theme-changed', { detail: next }));\n"

for f in files:
    with open(f, 'r', encoding='utf-8') as fh:
        content = fh.read()
    
    # Only inject once, only in files that have the theme toggle
    marker = "localStorage.setItem('atlas-theme', next);"
    if marker in content and 'atlas-theme-changed' not in content:
        content = content.replace(
            marker,
            marker + "\n" + INSERT
        )
        with open(f, 'w', encoding='utf-8') as fh:
            fh.write(content)
        print('Updated:', f)

print('Done')
