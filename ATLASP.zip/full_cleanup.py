import glob
import re
import os

files = glob.glob('c:/Users/hp/Desktop/Audit interne/atlas-audit-platform/frontend/*.html')

# Get the clean sidebar from dashboard.html
with open('c:/Users/hp/Desktop/Audit interne/atlas-audit-platform/frontend/dashboard.html', 'r', encoding='utf-8') as f:
    dash_content = f.read()
    sidebar_match = re.search(r'<aside class="sidebar">.*?</aside>', dash_content, flags=re.DOTALL)
    clean_sidebar = sidebar_match.group(0) if sidebar_match else ""

for fpath in files:
    fname = os.path.basename(fpath)
    if fname == 'upload.html':
        continue
        
    with open(fpath, 'r', encoding='utf-8') as f:
        content = f.read()

    # 1. Remove FontAwesome CDN
    content = content.replace('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">\n', '')
    content = content.replace('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">', '')

    # 2. Revert FontAwesome to ICONS
    # First, undo the specific anomalies.html replacements
    if fname == 'anomalies.html':
        content = content.replace(
            '<div style="width:34px;height:34px;border-radius:var(--radius-sm);background:var(--risk-critical-bg);display:flex;align-items:center;justify-content:center;"><i class="fa-solid fa-copy" style="color:var(--risk-critical-fill);font-size:0.85rem;"></i></div>',
            '<div style="width:32px;height:32px;border-radius:4px;background:var(--risk-critical-bg);color:var(--risk-critical-fill);display:flex;align-items:center;justify-content:center;font-size:1.2rem;"><script>document.write(ICONS.alert)</script></div>'
        )
        content = content.replace(
            '<div style="width:34px;height:34px;border-radius:var(--radius-sm);background:var(--risk-moderate-bg);display:flex;align-items:center;justify-content:center;"><i class="fa-solid fa-triangle-exclamation" style="color:var(--risk-moderate-fill);font-size:0.85rem;"></i></div>',
            '<div style="width:32px;height:32px;border-radius:4px;background:var(--risk-moderate-bg);color:var(--risk-moderate-fill);display:flex;align-items:center;justify-content:center;font-size:1.2rem;"><script>document.write(ICONS.alert)</script></div>'
        )
        content = content.replace(
            '<div style="width:34px;height:34px;border-radius:var(--radius-sm);background:var(--risk-high-bg);display:flex;align-items:center;justify-content:center;"><i class="fa-solid fa-chart-line" style="color:var(--risk-high-fill);font-size:0.85rem;"></i></div>',
            '<div style="width:32px;height:32px;border-radius:4px;background:var(--risk-high-bg);color:var(--risk-high-fill);display:flex;align-items:center;justify-content:center;font-size:1.2rem;"><script>document.write(ICONS.alert)</script></div>'
        )

    # General replacements
    replacements = {
        '<i class="fa-solid fa-triangle-exclamation"></i>': '<script>document.write(ICONS.alert)</script>',
        '<i class="fa-solid fa-circle" style="color:var(--risk-critical-fill);"></i>': '<span style="color:var(--color-error);"><script>document.write(ICONS.alert)</script></span>',
        '<i class="fa-solid fa-circle" style="color:var(--risk-moderate-fill);"></i>': '<span style="color:var(--color-gold);"><script>document.write(ICONS.alert)</script></span>',
        '<i class="fa-solid fa-circle" style="color:var(--risk-high-fill);"></i>': '<span style="color:var(--color-warning);"><script>document.write(ICONS.alert)</script></span>',
        '<i class="fa-solid fa-clipboard-list"></i>': '<script>document.write(ICONS.report)</script>',
        '<i class="fa-solid fa-ruler"></i>': '<script>document.write(ICONS.gaps)</script>',
        '<i class="fa-solid fa-magnifying-glass"></i>': '<script>document.write(ICONS.search)</script>',
        '<i class="fa-solid fa-bolt"></i>': '<script>document.write(ICONS.anomaly)</script>',
        '<i class="fa-solid fa-circle-check"></i>': '<script>document.write(ICONS.check)</script>',
        '<i class="fa-solid fa-cloud-arrow-up"></i>': '<script>document.write(ICONS.arrow_right)</script>'
    }
    for fa, svg in replacements.items():
        content = content.replace(fa, svg)
        
    # Also catch other font-awesome icons that might have been injected
    content = re.sub(r'<i class="fa-solid fa-[^"]+"></i>', '<script>document.write(ICONS.alert)</script>', content)

    # 3. Replace sidebar with the correct one
    # Replace either <nav class="sidebar"> or <aside class="sidebar">
    content = re.sub(r'<nav class="sidebar">.*?</nav>', clean_sidebar, content, flags=re.DOTALL)
    if fname != 'dashboard.html':
        content = re.sub(r'<aside class="sidebar">.*?</aside>', clean_sidebar, content, flags=re.DOTALL)
        
        # Update active state for sidebar items
        # First remove active from dashboard
        content = content.replace('class="nav-item active"', 'class="nav-item "')
        # Then add active to current page
        page_slug = fname.replace('.html', '')
        content = content.replace(f'href="/{page_slug}" class="nav-item "', f'href="/{page_slug}" class="nav-item active"')

    # Fix duplicated "Export PDF" if they are in both topbar and page-header.
    # Actually the user prompt requested it in topbar. We can remove it from page-header if it exists.
    content = content.replace('<button class="btn btn-ghost" onclick="window.location.href=\'/report\'">\n                        <script>document.write(ICONS.download)</script> Export Report\n                    </button>', '')

    with open(fpath, 'w', encoding='utf-8') as f:
        f.write(content)

print('Full cleanup applied.')
