import sys
sys.path.insert(0, '.')

errors = []

try:
    from backend.modules.ingestion import load_demo_data
    from backend.modules.risk_engine import get_all_risks, enrich_risks
    from backend.modules.monte_carlo import run_simulation
    from backend.modules.benford import analyze_benford, detect_anomalies
    from backend.modules.control_gaps import analyze_controls
    from backend.modules.sampling import run_mus_sampling
    from backend.modules.report_gen import generate_docx_report
    from backend.config import Config
    print("All imports: OK")
except Exception as e:
    print("IMPORT ERROR:", e)
    errors.append(e)
    sys.exit(1)

# 1. Validate risk level math
risks = get_all_risks()
for r in risks:
    s = r['risk_score']
    expected = 'Critical' if s >= 16 else 'High' if s >= 9 else 'Moderate' if s >= 4 else 'Low'
    if r['risk_level'] != expected:
        msg = "LEVEL MISMATCH %s: score=%d stored=%s expected=%s" % (r['risk_id'], s, r['risk_level'], expected)
        print(msg)
        errors.append(msg)
print("Risk level validation: OK (%d risks)" % len(risks))

# 2. Verify all IIA fields
required = ['risk_id','name','category','coso_component','likelihood','impact',
            'risk_score','risk_level','condition','criteria','cause','effect',
            'recommendation','evidence_source','department']
for r in risks:
    missing = [f for f in required if f not in r]
    if missing:
        msg = "MISSING FIELDS %s: %s" % (r['risk_id'], missing)
        print(msg)
        errors.append(msg)
print("IIA fields: OK")

# 3. Monte Carlo order check
mc = run_simulation(risks)
for rid, vals in mc.items():
    if not (vals['min_exposure'] <= vals['expected_exposure'] <= vals['max_exposure']):
        msg = "MC ORDER ERROR for %s" % rid
        print(msg)
        errors.append(msg)
print("Monte Carlo P10 <= P50 <= P90: OK")

# 4. Sampling conclusion field
import pandas as pd
import numpy as np
df = pd.DataFrame({
    'Amount_MAD': np.random.uniform(1000, 50000, 200),
    'Date': '2024-01-01',
    'Vendor_Customer': 'TEST'
})
res = run_mus_sampling(df)
if 'conclusion' not in res:
    msg = "MISSING: conclusion field in sampling result"
    print(msg)
    errors.append(msg)
if 'selected_transactions' not in res:
    msg = "MISSING: selected_transactions in sampling result"
    print(msg)
    errors.append(msg)
print("Sampling result fields: OK")

# 5. Control gaps _OUTDATED_YEARS includes 2021
from backend.modules.control_gaps import _OUTDATED_YEARS
assert '2021' in _OUTDATED_YEARS, "2021 missing from outdated years"
assert '2019' in _OUTDATED_YEARS, "2019 missing from outdated years"
print("Control gaps outdated years: OK (%s)" % sorted(_OUTDATED_YEARS))

print("\n=== FINAL: %d errors ===" % len(errors))
if errors:
    print("ERRORS:", errors)
else:
    print("ALL CHECKS PASSED")
